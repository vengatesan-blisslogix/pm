angular.module('500tech.simple-calendar', []).directive('simpleCalendar', function () {

    debugger;
    return {
        restrict: 'E',
        scope: {
            options: '=?',
            events: '=?'
        },
        template: '<div class="calendar">' +
          '<div class="current-month">' +
          '<div class="move-month prev-month" ng-click="prevMonth()">' +
          '<span ng-show="allowedPrevMonth()">&#x2039;</span>' +
          '</div>' +
          '<span>{{ selectedMonth }}</span>' +
          '&nbsp;' +
          '<span>{{ selectedYear }}</span>' +
          '<div class="move-month next-month" ng-click="nextMonth()">' +
          '<span ng-show="allowedNextMonth()">&#x203a;</span>' +
          '</div>' +
          '</div>' +
          '<div>' +
          '<div ng-repeat="day in weekDays(options.dayNamesLength) track by $index" class="weekday">{{ day }}</div>' +
          '</div>' +
          '<div>' +          
          '<div ng-repeat="week in weeks track by $index" class="week">' +
          '<div class="custom-day"' +

          // sundayhide & jollyday hide add here :-

        //'ng-class="{default: isDefaultDate(date),clickeddate:date.clicked, event: date.event, disabled: date.disabled || !date,sundayhide:date.datehide,jollydayhide:date.jollyday}"' +

        // jollyday hide add here :-
        'ng-class="{default: isDefaultDate(date),clickeddate:date.clicked, event: date.event, disabled: date.disabled || !date,sundayhide:date.datehide,jollydayhide:date.jollyday}"' +

        'ng-repeat="date in week  track by $index"' +
          'ng-click="date.datehide || onClick(date)">' +
          '<div class="day-number">{{ date.day || "&nbsp;" }}</div>' +
          '<div class="event-title">{{ date.event.title || "&nbsp;" }}</div>' +
          ' </div>' +
          '</div>' +
          '</div>' +
          '</div>',
        controller: ['$scope', '$rootScope', function ($scope, $rootScope) {
            var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            var WEEKDAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
            var calculateSelectedDate, calculateWeeks, allowedDate, bindEvent;
            
            $scope.options = $scope.options || {};
            $scope.options.dayNamesLength = $scope.options.dayNamesLength || 1;

            // It Displays FROM CLICK DATE TO SUNDAY :-
            //==========================================

            //$scope.onClick = function (date) {
            //    debugger;
            //    $scope.storedata = null;
            //    $scope.dates = {};
            //    $scope.dates.senddata = [];
            //    $scope.dates.senddays = [];
            //    var count = 0;
            //    for (var i = 0; i < $scope.weeks.length; i++) {
            //        for (var j = 0; j < $scope.weeks[i].length; j++) {
            //            if ($scope.weeks[i][j] != null)
            //                if (date.day == $scope.weeks[i][j].day) {
            //                    debugger;
            //                    $scope.weeks[i][j].clicked = true;
            //                    $scope.storedata = i;
            //                }
            //                else {
            //                    $scope.weeks[i][j].clicked = false;
            //                }
            //            if ($scope.storedata != null) {
            //                debugger;
            //                if ($scope.weeks[i][j] != null) {
            //                    $scope.dates.senddata[count] = $scope.weeks[i][j].day + "/" + $scope.weeks[i][j].month + "/" + $scope.weeks[i][j].year;
            //                    $scope.dates.senddays[count] = WEEKDAYS[j];
            //                }
            //                if ($scope.storedata != i || $scope.weeks[i][j] == null) {
            //                    $scope.storedata = null;
            //                    $scope.$emit("df", $scope.dates);
            //                }
            //                count++;
            //            }
            //        }
            //    }
            //    if (!date || date.disabled) { return; }
            //    if (date.event) {
            //        $scope.options.eventClick(date);
            //    }
            //};

          
            // It Displays ONLY SUNDAY Hide function :-
            //=========================================
            $scope.hidefn = function () {
                for (var i = 0; i < $scope.weeks.length; i++) {
                    for (var j = 0; j < $scope.weeks[i].length; j++) {
                        if (j == 0 && $scope.weeks[i][j] != null) {
                            $scope.weeks[i][j].datehide = true;
                        }
                    }
                }
            }

            //Holiday function:-
            //==================

            //emit calling here using "ON" function 
            $scope.$on('hldy', function (event, holidays) {
                debugger;
                $scope.holidays = holidays;
                for (var i = 0; i < $scope.weeks.length; i++) {
                    for (var j = 0; j < $scope.weeks[i].length; j++) {
                        if ($scope.weeks[i][j] != null) {
                            for (var k = 0; k < $scope.holidays.length; k++) {
                                $scope.HolidayYear = new Date($scope.holidays[k].date).getFullYear();
                                $scope.HolidayMonth = new Date($scope.holidays[k].date).getMonth();
                                $scope.HolidayDay = new Date($scope.holidays[k].date).getDate();

                                if ($scope.HolidayYear == $scope.weeks[i][j].year &&
                                    $scope.HolidayMonth == $scope.weeks[i][j].month &&
                                    $scope.HolidayDay == $scope.weeks[i][j].day) {
                                    $scope.weeks[i][j].jollyday = true;
                                }
                            }
                        }
                    }
                }
            });

            // It DISPLAYS SUN TO SAT DAY :-
            //=============================
            $scope.onClick = function (date) {
                debugger;
                date.month=date.month
                // jollyday - true so it's checking date.jollyday then comesout from the if loop
                if (date.jollyday) {
                    return;
                }
                $scope.storedata = null;
                $scope.dates = {};
                $scope.dates.senddata = [];
                $scope.dates.senddays = [];
                var count = 0;
                for (var i = 0; i < $scope.weeks.length; i++) {
                    for (var j = 0; j < $scope.weeks[i].length; j++) {
                        if ($scope.weeks[i][j] != null)
                            if (date.day == $scope.weeks[i][j].day && date.month == $scope.weeks[i][j].month)
                            {
                                debugger;
                                $scope.weeks[i][j].clicked = true;
                                for (var k = 0; k < $scope.weeks[i].length; k++) {
                                    if ($scope.weeks[i][k] != null) {
                                        //month added 1 here
                                     var month = parseInt($scope.weeks[i][k].month) + 1;
                                        $scope.dates.senddata[count] = $scope.weeks[i][k].day + "/" +
                                                                       month + "/" +
                                                                       $scope.weeks[i][k].year;
                                        $scope.dates.senddays[count] = WEEKDAYS[k];
                                        count++;
                                    } else {
                                        //$scope.dates.senddata[count] = "";
                                        //$scope.dates.senddays[count] = "";
                                    }                                    
                                }
                                $scope.$emit("df", $scope.dates);

                            }
                            else {
                                $scope.weeks[i][j].clicked = false;
                            }
                    }
                }
                if (!date || date.disabled) { return; }
                if (date.event) {
                    $scope.options.eventClick(date);
                }
            };


            // that's it calendar function

            if ($scope.options.minDate) {
                $scope.options.minDate = new Date($scope.options.minDate);
            }

            if ($scope.options.maxDate) {
                $scope.options.maxDate = new Date($scope.options.maxDate);
            }

            bindEvent = function (date) {
                if (!date || !$scope.events) { return; }
                $scope.events.forEach(function (event) {
                    event.date = new Date(event.date);
                    if (date.year === event.date.getFullYear() && date.month === event.date.getMonth() && date.day === event.date.getDate()) {
                        date.event = event;
                    }
                });
            };

            allowedDate = function (date) {
                if (!$scope.options.minDate && !$scope.options.maxDate) {
                    return true;
                }
                var currDate = new Date([date.year, date.month + 1, date.day]);
                if ($scope.options.minDate && (currDate < $scope.options.minDate)) { return false; }
                if ($scope.options.maxDate && (currDate > $scope.options.maxDate)) { return false; }
                return true;
            };
            // $scope.minDate=new Date();
            $scope.allowedPrevMonth = function () {
                var prevYear = null;
                var prevMonth = null;
                if (!$scope.options.minDate) { return true; }
                var currMonth = MONTHS.indexOf($scope.selectedMonth);
                if (currMonth === 0) {
                    prevYear = ($scope.selectedYear - 1);
                } else {
                    prevYear = $scope.selectedYear;
                }
                if (currMonth === 0) {
                    prevMonth = 11;
                } else {
                    prevMonth = (currMonth - 1);
                }
                if (prevYear < $scope.options.minDate.getFullYear()) { return false; }
                if (prevYear === $scope.options.minDate.getFullYear()) {
                    if (prevMonth < $scope.options.minDate.getMonth()) { return false; }
                }
                return true;
            };

            $scope.allowedNextMonth = function () {
                var nextYear = null;
                var nextMonth = null;
                if (!$scope.options.maxDate) { return true; }
                var currMonth = MONTHS.indexOf($scope.selectedMonth);
                if (currMonth === 11) {
                    nextYear = ($scope.selectedYear + 1);
                } else {
                    nextYear = $scope.selectedYear;
                }
                if (currMonth === 11) {
                    nextMonth = 0;
                } else {
                    nextMonth = (currMonth + 1);
                }
                if (nextYear > $scope.options.maxDate.getFullYear()) { return false; }
                if (nextYear === $scope.options.maxDate.getFullYear()) {
                    if (nextMonth > $scope.options.maxDate.getMonth()) { return false; }
                }
                return true;
            };

            //calculateWeeks = function () {
            //    $scope.weeks = [];
            //    var week = null;
            //    var daysInCurrentMonth = new Date($scope.selectedYear, MONTHS.indexOf($scope.selectedMonth) + 1, 0).getDate();
            //    for (var day = 1; day < daysInCurrentMonth + 1; day += 1) {
            //        var dayNumber = new Date($scope.selectedYear, MONTHS.indexOf($scope.selectedMonth), day).getDay();
            //        week = week || [null, null, null, null, null, null, null];
            //        week[dayNumber] = {
            //            year: $scope.selectedYear,
            //            month: MONTHS.indexOf($scope.selectedMonth),
            //            day: day
            //        };

            //        if (allowedDate(week[dayNumber])) {
            //            if ($scope.events) { bindEvent(week[dayNumber]); }
            //        } else {
            //            week[dayNumber].disabled = true;
            //        }

            //        if (dayNumber === 6 || day === daysInCurrentMonth) {
            //            $scope.weeks.push(week);
            //            week = undefined;
            //        }
            //    }
            //    //sunday hide function
            //    $scope.hidefn();
            //};

            // palani said
            calculateWeeks = function () {

                $scope.weeks = [];
                var week = null;
                var daysInCurrentMonth = new Date($scope.selectedYear, MONTHS.indexOf($scope.selectedMonth) + 1, 0).getDate();

                for (var day = 1; day < daysInCurrentMonth + 1; day += 1) {
                    var dayNumber = new Date($scope.selectedYear, MONTHS.indexOf($scope.selectedMonth), day-1).getDay();
                    week = week || [null, null, null, null, null, null, null];
                    week[dayNumber] = {
                        year: $scope.selectedYear,
                        month: MONTHS.indexOf($scope.selectedMonth),
                        day: day,
                        dble: false
                    };
                    if (allowedDate(week[dayNumber])) {
                        if ($scope.events) {
                            bindEvent(week[dayNumber]);
                        }
                    }
                    else {
                        week[dayNumber].disabled = true;
                    }

                    if (dayNumber === 6 || day === daysInCurrentMonth) {
                        $scope.weeks.push(week);
                        week = undefined;
                    }
                }

                var mn = MONTHS.indexOf($scope.selectedMonth)
                var LastDayPrevMonth = new Date($scope.selectedYear, mn, 0).getDate();
                var arrCnt = 0;
                function allNull(arr) {
                    var all_null = arr.every(function (v) {
                        if (v === null) {
                            arrCnt++
                        }
                        return arrCnt;
                    });
                }

                var incDay = 1;
                var nxtMnth;
                var nxtYr;
                for (i = 0; i < $scope.weeks.length; i++) {
                    if (i == 0) {
                        allNull($scope.weeks[i]);
                    }
                    var dy = $scope.weeks[i];
                    for (j = 0; j < dy.length; j++) {
                        if (i == 0)//first array
                        {
                            if (dy[j]) {

                            }
                            else //null;
                            {

                                var lstMnthStrDt = LastDayPrevMonth - (arrCnt - 1);
                                var mnth = MONTHS.indexOf($scope.selectedMonth);
                                if (mnth == 0)//January
                                {
                                    preMnth = 11;
                                    preYr = $scope.selectedYear - 1;
                                }
                                else {
                                    preMnth = mnth - 1;
                                    preYr = $scope.selectedYear;
                                }

                                var obj = {
                                    year: preYr,
                                    month: preMnth,
                                    day: lstMnthStrDt + j,
                                    dble: true
                                }

                                dy[j] = obj;

                            }
                        }
                        else if (i == 4 || i == 5)//last array 
                        {

                            if (dy[j]) {
                            }
                            else //null
                            {
                                var mnth = MONTHS.indexOf($scope.selectedMonth);
                                if (mnth == 11) {
                                    nxtMnth = 0;
                                    nxtYr = $scope.selectedYear + 1;
                                }
                                else {
                                    nxtMnth = mnth + 1;
                                    nxtYr = $scope.selectedYear;
                                }
                                var obj = {
                                    year: nxtYr,
                                    month: nxtMnth,
                                    day: incDay,
                                    dble: true
                                }

                                dy[j] = obj;
                                incDay++;

                            }

                        }
                    }

                }

                // console.log(JSON.stringify($scope.weeks));
                //sunday hide function
                //$scope.hidefn();
            };

            calculateSelectedDate = function () {
                debugger;
                if ($scope.options.defaultDate) {
                    $scope.options._defaultDate = new Date($scope.options.defaultDate);
                } else {
                    $scope.options._defaultDate = new Date();
                }

                // get full month , year , date from here 
                $scope.selectedYear = $scope.options._defaultDate.getFullYear();
                $scope.selectedMonth = MONTHS[$scope.options._defaultDate.getMonth()];
                $scope.selectedDay = $scope.options._defaultDate.getDate();
                calculateWeeks();
            };

            $scope.weekDays = function (size) {
                return WEEKDAYS.map(function (name) { return name.slice(0, size) });
            };
            $scope.defaultdatechecked = false;
            $scope.isDefaultDate = function (date) {

                if (!date) { return; }

                if (date.year === $scope.options._defaultDate.getFullYear() &&
                  date.month === $scope.options._defaultDate.getMonth() &&
                  date.day === $scope.options._defaultDate.getDate() && !$scope.defaultdatechecked) {

                    $scope.defaultdatechecked = true;
                    $scope.onClick(date);
                    return true;
                }
                else {
                    return false;
                }
            };

            $scope.prevMonth = function () {
                $scope.dates = {};
                $rootScope.$broadcast("df", $scope.dates);
                if (!$scope.allowedPrevMonth()) { return; }
                var currIndex = MONTHS.indexOf($scope.selectedMonth);
                if (currIndex === 0) {
                    $scope.selectedYear -= 1;
                    $scope.selectedMonth = MONTHS[11];
                } else {
                    $scope.selectedMonth = MONTHS[currIndex - 1];
                }
                calculateWeeks();

                var prevIndex = MONTHS.indexOf($scope.selectedMonth);

                var date={};
                date.year = $scope.selectedYear;
                date.month = prevIndex;
                date.day = 1;

                $scope.onClick(date);

            };
            $scope.nextMonth = function () {

                $scope.dates = {};
                $rootScope.$broadcast("df", $scope.dates);
                if (!$scope.allowedNextMonth()) { return; }
                var currIndex = MONTHS.indexOf($scope.selectedMonth);
                if (currIndex === 11) {
                    $scope.selectedYear += 1;
                    $scope.selectedMonth = MONTHS[0];
                } else {
                    $scope.selectedMonth = MONTHS[currIndex + 1];
                }
                calculateWeeks();
                var nextIndex = MONTHS.indexOf($scope.selectedMonth);

                var date={};
                date.year = $scope.selectedYear;
                date.month = nextIndex;
                date.day = 1;
                $scope.onClick(date);

            };

            $scope.$watch('options.defaultDate', function () {
                calculateSelectedDate();
            });

            $scope.$watch('events', function () {
                calculateWeeks();
            });

        }]
    }
});